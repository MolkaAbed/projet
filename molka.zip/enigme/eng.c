
/**
* @file eng.c
*/

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "eng.h"

/**
* @brief To initialiser enigme .
* @param e
* @return Nothing
*/
void init_enigme(enigme * e)
{
	e->p.x=0;
	e->p.y=0;
	e->img=NULL;
}

/**
* @brief To generation affichage.
* @param image
* @param screen
* @param e
* @param alea
* @return Nothing
*/
 void generate_afficher (SDL_Surface * screen  , char image [],enigme *e,int *alea)
{
	

int test=*alea;
do
{

*alea = 1+ rand()%3;
}while(*alea==test);

 sprintf(image ,"%d.png",*alea);
e->img = IMG_Load(image);
 SDL_BlitSurface(e->img,NULL,screen,&(e->p)) ;
  SDL_Flip(screen) ;
}
/**
* @brief To solution .
* @param image
* @return integer
*/


 int solution(char image [])
 {
 	int solution =0 ;

 	if(strcmp(image,"1.png")==0)
 	{
     solution =1 ;
 	}
 	 else if(strcmp(image,"2.png")==0)
 	{
 		solution =1;

 	}
 	else if(strcmp(image,"3.png")==0)
 	{
 		solution =2;
 	}
 	return solution;
 }
/**
* @brief To resolution .
* @param running
* @param run
* @return integer
*/

int resolution (int * running,int *run )
{
	SDL_Event event ;
  int r=0;
	SDL_PollEvent(&event);
	switch(event.type)
	{
		  case SDL_QUIT:
				*running= 0 ;
                *run = 0;
			break ;
/*SDL_WaitEvent(&event);*/	
       case SDL_MOUSEBUTTONUP:
                {  
 if( event.button.button==SDL_BUTTON_LEFT)
        {
                	
			  if(event.button.x>86 && event.button.x<181 && event.button.y>470 && event.button.y<580 )
			  	r=1;
			  else if (event.button.x>276 &event.button.x<374 && event.button.y>470 && event.button.y<580)
			  	r=2;
	}		    }
       break ;
	}
  return r ;
}
/**
* @brief To affichage resultat .
* @param screen
* @param s
* @param r
* @param en
* @return Nothing
*/
 void afficher_resultat (SDL_Surface * screen,int s,int r,enigme *en)
 {
 	en->p1.x=500;
	en->p1.y=250;
 	if (r==s)
 	{
 		en->img=IMG_Load("00.png");
 		
        
 		SDL_BlitSurface(en->img, NULL, screen, &(en->p1)) ;
        SDL_Flip(screen);
 	}
 	else
 	{
 		en->img=IMG_Load("11.png");
 		SDL_BlitSurface(en->img, NULL, screen, &(en->p1)) ;
        SDL_Flip(screen);
 	}
 }
