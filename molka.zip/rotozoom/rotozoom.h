/**
* @file rotozoom.h
*/

#ifndef ENIGME_H_INCLUDED
#define ENIGMLE_H_INCLUDED

void rotozoom();
#endif
